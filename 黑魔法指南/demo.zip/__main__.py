import calc 

print(calc.add(2, 3))
