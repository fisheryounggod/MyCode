correlation = cor(df$price, df$mpg)
print(dim(df))

