# This is a regular R script file
print(dim(df))
correlation = cor(df$price, df$mpg)
mat2 = mat^2
print(mat2)
